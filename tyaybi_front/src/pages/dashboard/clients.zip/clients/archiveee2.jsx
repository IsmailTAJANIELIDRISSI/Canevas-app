const handleSliceExcel = async () => {
  if (!file) {
    return alert('Please select an Excel file');
  }
  setLoading(true);
  const reader = new FileReader();
  reader.readAsArrayBuffer(file);
  reader.onload = (event) => {
    const arrayBuffer = event.target.result;
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    const header = [
      'Identifiant unique du fichier', "N° ordre de l'article", "Nombre Contenants",
      "Type Contenant", "Marque (N° Envoi)", "Code NGP(à 10 chiffres)",
      "Désignation commerciale", "Pays d'origine", "Indicateur de Paiement",
      "Indicateur Occasion", "Valeur", "Devise", "Quantité Article",
      "Unité de mesure", "Poids net Article", "Quantité normalisée",
      "Code Référence Accord Article", "Code Référence Franchise",
      "Nom et Prénom", "CIN", "Carton or bag N°", "HAWB"
    ];
    const ngpMap = {};
    // for (const item of bddngp.Feuil1) {
    //   // Normalize the designation by removing trailing numbers and spaces
    //   const key = item["Désignation commerciale"]
    //     .toLowerCase()
    //     .replace(/\s*\d*$/, '')
    //     .trim();
        
    //   if (!ngpMap[key]) {
    //     ngpMap[key] = item["Code NGP(à 10 chiffres)"];
    //   }
    // }
    
    function findNgpCode(description) {
      const originalKey = description.toLowerCase();
      
      // First try to find the ngpCode with the original key
      if (ngpMap[originalKey]) {
        return ngpMap[originalKey];
      }
    
      const normalizedKey = originalKey.replace(/\s*\d*$/, '').trim();
      return ngpMap[normalizedKey] || 'ngp';
    }

    setPoidbrut(extractNumber(jsonData[3][0]?jsonData[3][0]:0));
    setParvaleur(extractNumber(jsonData[3][1]?jsonData[3][1]:0));
    setPosition(extractNumber(jsonData[2][0]?jsonData[2][0]:0));
    setColiis(extractNumber(jsonData[3][2]?jsonData[3][2]:0));
  
    let poidbr =extractNumber(jsonData[3][0]?jsonData[3][0]:0);
    let parv =extractNumber(jsonData[3][1]?jsonData[3][1]:0);
    let pos =extractNumber(jsonData[2][0]?jsonData[2][0]:0);
    let coli =extractNumber(jsonData[3][2]?jsonData[3][2]:0);
    const mawbValue = jsonData[0][0] ? jsonData[0][0] : "mawb";
    setMawb(mawbValue);
    
    
    function extractNumber(str) {
      if (typeof str !== 'string') {
        return str;
      }
      const match = str.match(/\d+(\.\d+)?/);
      return match ? parseFloat(match[0]) : null;
    }
    let contactexiste = jsonData[4][6];
    let ngpexiste =contactexiste =="Contact" ?jsonData[4][14]:jsonData[4][13];

    
    const slicedSheets = [];
    let currentSheet = [];
    const processedWaybills = new Set();
    let newdata = [];
    let sheetCount = 1;
    let missingNGPCodes = [];
    let accumulatedTotalValue = 0;
    let weightt = 0;
    for (let i = 5; i < jsonData.length - 1; i++) {
      
      const row = jsonData[i];
      if (row[0] && row[0].toLowerCase() === "total") {
        break;
      }
      if(contactexiste =="Contact"){
        weightt += Number(row[10]);
      }else{
        weightt += Number(row[9]);
      }
      
    }
    const trueremaining = []
    for (let i = 5; i < jsonData.length - 1; i++) {
      
      const row = jsonData[i];
      if (row[0] && row[0].toLowerCase() === "total") {
        break;
      }
      let ngpCode;
      const waybillNumber = row[1];
      const description = row[2];
     
      
      let pieces = Number(row[3]);
      let total = Number(row[4]);
      if(contactexiste =="Contact"){
        var weight = Number(row[10]);
      }else{
        var weight = Number(row[9]);
      }
      
      if (ngpexiste == "ngp") {
        if (contactexiste == "Contact") {
          ngpCode = row && row[14] != null ? row[14] : 'ngp';
        } else {
          ngpCode = row && row[13] != null ? row[13] : 'ngp';
        }
      } else {
        let codePrefix;
        if (contactexiste == "Contact") {
          codePrefix = row && row[13] != null ? row[13].toString().substring(0, 2) : null;
        } else {
          codePrefix = row && row[12] != null ? row[12].toString().substring(0, 2) : null;
        }
      
        switch (true) {
          case (codePrefix >= "01" && codePrefix <= "22"):
            ngpCode = 2104200000;
            break;
          case (codePrefix == "30"):
            ngpCode = 3006500000;
            break;
          case (codePrefix >= "32" && codePrefix <= "38"):
            ngpCode = 3304100000;
            break;
          case (codePrefix == "39"):
            ngpCode = 3926909290;
            break;
          case (codePrefix == "40"):
            ngpCode = 4016999800;
            break;
          case (codePrefix >= "41" && codePrefix <= "42"):
            ngpCode = 4202110010;
            break;
          case (codePrefix >= "44" && codePrefix <= "46"):
            ngpCode = 4409101000;
            break;
          case (codePrefix >= "48" && codePrefix <= "49"):
            ngpCode = 4901991000;
            break;
          case (codePrefix >= "50" && codePrefix <= "63"):
            ngpCode = 6203120000;
            break;
          case (codePrefix >= "64" && codePrefix <= "65"):
            ngpCode = 6401101000;
            break;
          case (codePrefix >= "66" && codePrefix <= "67"):
            ngpCode = 6602000000;
            break;
          case (codePrefix >= "68" && codePrefix <= "69"):
            ngpCode = 6904100010;
            break;
          case (codePrefix == "70"):
            ngpCode = 7007111011;
            break;
          case (codePrefix == "71"):
            ngpCode = 7113199000;
            break;
          case (codePrefix >= "72" && codePrefix <= "82"):
            ngpCode = 8201100010;
            break;
          case (codePrefix == "83"):
            ngpCode = 8306300000;
            break;
          case (codePrefix >= "84" && codePrefix <= "89"):
              let codesufix;
              if(codePrefix == "85"){
                if (contactexiste == "Contact") {
                  codesufix = row && row[13] != null ? row[13].toString().substring(2, 4) : null;
                } else {
                  codesufix = row && row[12] != null ? row[12].toString().substring(2, 4) : null;
                }
                ngpCode = codesufix == "44"? 8544429090 :codesufix == "04"? 8504409980 :8512100000
              }else{
                ngpCode = 8512100000;
              }
              
              break;
          case (codePrefix >= "90" && codePrefix <= "92"):
            ngpCode = 9002111000;
            break;
          case (codePrefix == "94"):
            ngpCode = 9401100000;
            break;
          case (codePrefix == "95"):
            ngpCode = 9503001010;
            break;
          case (codePrefix == "96"):
            ngpCode = 9608109000;
            break;
          default:
            ngpCode = 'ngp'; 
        }
      }
      if (ngpCode == 'ngp') {
        
        console.log(description);
        console.log(waybillNumber);
        console.log(i);
      }
      if (ngpCode == 'ngp') {
        ngpCode = description ? (ngpMap[description.toLowerCase()] || findNgpCode(description.toLowerCase())) : 'ngp';
      }
      if (!ngpCode) {
        ngpCode = description ? (ngpMap[description.toLowerCase()] || findNgpCode(description.toLowerCase())) : 'ngp';
      }
      
      if (ngpCode == 'ngp') {
        missingNGPCodes.push(description);
       
      }

      for (let j = i + 1; j < jsonData.length; j++) {
        
        const nextRow = jsonData[j];
        if (nextRow[0] && nextRow[0].toLowerCase() === "total") {
          break;
        }
        let ngpCodee;
        if (ngpexiste == "ngp") {
          if (contactexiste == "Contact") {
            ngpCodee = nextRow && nextRow[14] != null ? nextRow[14] : 'ngp';
          } else {
            ngpCodee = nextRow && nextRow[13] != null ? nextRow[13] : 'ngp';
          }
        } else{
          let codePrefix;
          if (contactexiste == "Contact") {
            codePrefix = nextRow && nextRow[13] != null ? nextRow[13].toString().substring(0, 2) : null;
          } else {
            codePrefix = nextRow && nextRow[12] != null ? nextRow[12].toString().substring(0, 2) : null;
          }
          
          switch (true) {
            case (codePrefix >= "01" && codePrefix <= "22"):
              ngpCodee = 2104200000;
              break;
            case (codePrefix == "30"):
              ngpCodee = 3006500000;
              break;
            case (codePrefix >= "32" && codePrefix <= "38"):
              ngpCodee = 3304100000;
              break;
            case (codePrefix == "39"):
              ngpCodee = 3926909290;
              break;
            case (codePrefix == "40"):
              ngpCodee = 4016999800;
              break;
            case (codePrefix >= "41" && codePrefix <= "42"):
              ngpCodee = 4202110010;
              break;
            case (codePrefix >= "44" && codePrefix <= "46"):
              ngpCodee = 4409101000;
              break;
            case (codePrefix >= "48" && codePrefix <= "49"):
              ngpCodee = 4901991000;
              break;
            case (codePrefix >= "50" && codePrefix <= "63"):
              ngpCodee = 6203120000;
              break;
            case (codePrefix >= "64" && codePrefix <= "65"):
              ngpCodee = 6401101000;
              break;
            case (codePrefix >= "66" && codePrefix <= "67"):
              ngpCodee = 6602000000;
              break;
            case (codePrefix >= "68" && codePrefix <= "69"):
              ngpCodee = 6904100010;
              break;
            case (codePrefix == "70"):
              ngpCodee = 7007111011;
              break;
            case (codePrefix == "71"):
              ngpCodee = 7113199000;
              break;
            case (codePrefix >= "72" && codePrefix <= "82"):
              ngpCodee = 8201100010;
              break;
            case (codePrefix == "83"):
              ngpCodee = 8306300000;
              break;
            case (codePrefix >= "84" && codePrefix <= "89"):
              let codesufix;
              if(codePrefix == "85"){
                if (contactexiste == "Contact") {
                  codesufix = nextRow && nextRow[13] != null ? nextRow[13].toString().substring(2, 4) : null;
                } else {
                  codesufix = nextRow && nextRow[12] != null ? nextRow[12].toString().substring(2, 4) : null;
                }
                ngpCodee = codesufix == "44"? 8544429090 :codesufix == "04"? 8504409980 :8512100000
              }else{
                ngpCodee = 8512100000;
              }
              
              break;
            case (codePrefix >= "90" && codePrefix <= "92"):
              ngpCodee = 9002111000;
              break;
            case (codePrefix == "94"):
              ngpCodee = 9401100000;
              break;
            case (codePrefix == "95"):
              ngpCodee = 9503001010;
              break;
            case (codePrefix == "96"):
              ngpCodee = 9608109000;
              break;
            default:
              ngpCodee = 'ngp'; 
          }
        }
        
        if (ngpCodee == 'ngp') {
          ngpCodee = nextRow && nextRow[2] != null ? (ngpMap[nextRow[2].toLowerCase()] || findNgpCode(nextRow[2])) : 'ngp';
        }
        if (!ngpCodee) {
          ngpCodee = nextRow && nextRow[2] != null ? (ngpMap[nextRow[2].toLowerCase()] || findNgpCode(nextRow[2])) : 'ngp';
        }
        
        if (waybillNumber === nextRow[1]) {
          if (ngpCode === ngpCodee) {
            
            pieces += Number(nextRow[3]);
            total += Number(nextRow[4]);
            if(contactexiste =="Contact"){
              weight += Number(nextRow[10]);
            }else{
              weight += Number(nextRow[9]);
            }
            
          }
        } else {
         
          
        }
      }

      let rowExists = false;

      newdata.map(row => {
        const existingRow = row[0];
        if (existingRow[3] === waybillNumber && existingRow[4] === ngpCode) {
          rowExists = true; // Side effect of map (not recommended)
        }
        return null; // Since map expects a return value, we can return null or undefined
      });
      
      // You can remove the return value and just use forEach if you want.
      
      
      if (!rowExists && !exclusionWaybills.includes(waybillNumber)) {
        accumulatedTotalValue += total;// Accumulate the total value
        
        if (contactexiste == "Contact") {
          if (ngpCode == 8544429090 || ngpCode == 8504409980 || ngpCode == 9503001010 || 
              ngpCode == 9608109000 || ngpCode == 7007111011 || ngpCode == 6401101000 || 
              ngpCode == 4409101000 || ngpCode == 4202110010 || ngpCode == 4016999800 || 
              ngpCode == 3926909290 || ngpCode == 3301120010 || ngpCode == 6203120000 || ngpCode == 4901991000) {
              
              
              if (total > 500) {
                  let weightPercentage = (495 / total) * weight;
                  let piecesPercentage = Math.round((495 / total) * pieces);
                  let remainingTotal = total - 495;
                  let remainingWeight = weight - weightPercentage;
                  let remainingPieces = pieces - piecesPercentage;
                  let trueelectronic = 0
                  if (remainingPieces === 0) {
                    piecesPercentage -= 1;
                    remainingPieces = 1;
                    
                  }
                  if(piecesPercentage<1){
                    piecesPercentage = 1;
                    trueremaining.push(i-4)
                  }
                  newdata.push([
                      [
                          i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', 495, 
                          'MAD', piecesPercentage, '002', weightPercentage, piecesPercentage, '', '', row[6], '', row[11], row[12]
                      ]
                  ]);
                  newdata.map(row => {
                    const existingRow = row[0];
                  
                    if (existingRow[3] == waybillNumber && existingRow[4] == 85121000000) {
                      existingRow[9] += remainingTotal;
                      existingRow[11] += remainingPieces;
                      existingRow[13] += remainingWeight;
                      existingRow[14] += remainingPieces;
                      trueelectronic = 1; // Set trueelectronic to 1 if the condition is met
                    }
                  
                    return row; // Returning the original row (not necessary, but for consistency)
                  });
                  
                  if(trueelectronic !=1){
                            newdata.push([
                                [
                                    i - 4, '', '000', waybillNumber, 85121000000, 'electronic parts', 'CN', 'SP', 'NON', remainingTotal, 
                                    'MAD', remainingPieces, '002', remainingWeight, remainingPieces, '', '', row[6], '', row[11], row[12]
                                ]
                            ]);
                  }
                  
              } else {
                  // Push data as is
                  newdata.push([
                      [
                          i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', total, 
                          'MAD', pieces, '002', weight, pieces, '', '', row[6], '', row[11], row[12]
                      ]
                  ]);
              }
          } else {
              // Any other ngpCode
              newdata.push([
                  [
                      i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', total, 
                      'MAD', pieces, '002', weight, pieces, '', '', row[6], '', row[11], row[12]
                  ]
              ]);
          }
      } else {
          // Similar logic for the other case where contactexiste is not "Contact"
          if (ngpCode == 8544429090 || ngpCode == 8504409980 || ngpCode == 9503001010 || 
              ngpCode == 9608109000 || ngpCode == 7007111011 || ngpCode == 6401101000 || 
              ngpCode == 4409101000 || ngpCode == 4202110010 || ngpCode == 4016999800 || 
              ngpCode == 3926909290 || ngpCode == 3301120010 || ngpCode == 6203120000 || ngpCode == 4901991000) {
            
              if (total > 500) {
                  let weightPercentage = (495 / total) * weight;
                  let piecesPercentage = Math.round((495 / total) * pieces);
                  let remainingTotal = total - 495;
                  let remainingWeight = weight - weightPercentage;
                  let remainingPieces = pieces - piecesPercentage;
                  let trueelectronic = 0
                  if (remainingPieces === 0) {
                    piecesPercentage -= 1;
                    remainingPieces = 1;
                    
                  }
                  if(piecesPercentage<1){
                    piecesPercentage = 1;
                    trueremaining.push(i-4)
                  }
      
                  newdata.push([
                      [
                          i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', 495, 
                          'MAD', piecesPercentage, '002', weightPercentage, piecesPercentage, '', '', row[6], '', row[10], row[11]
                      ]
                  ]);
                  newdata.forEach(row => {
                    const existingRow = row[0];
                  
                    if (existingRow[3] == waybillNumber && existingRow[4] == 85121000000) {
                      existingRow[9] += remainingTotal;
                      existingRow[11] += remainingPieces;
                      existingRow[13] += remainingWeight;
                      existingRow[14] += remainingPieces;
                      trueelectronic = 1; // Set trueelectronic to 1 if the condition is met
                    }
                  });
                  
                  if(trueelectronic !=1){
                    newdata.push([
                      [
                          i - 4, '', '000', waybillNumber, 85121000000, 'electronic parts', 'CN', 'SP', 'NON', remainingTotal, 
                          'MAD', remainingPieces, '002', remainingWeight, remainingPieces, '', '', row[6], '', row[10], row[11]
                      ]
                  ]);
                  }
                  
              } else {
                  // Push data as is
                  newdata.push([
                      [
                          i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', total, 
                          'MAD', pieces, '002', weight, pieces, '', '', row[6], '', row[10], row[11]
                      ]
                  ]);
              }
          }  else {
              // Any other ngpCode
              newdata.push([
                  [
                      i - 4, '', '000', waybillNumber, ngpCode, removeNumbers(description), 'CN', 'SP', 'NON', total, 
                      'MAD', pieces, '002', weight, pieces, '', '', row[6], '', row[10], row[11]
                  ]
              ]);
          }
      }
      
      }
      else if (exclusionWaybills.includes(waybillNumber)){
        if (!processedWaybills.has(waybillNumber)) {
          // Perform the operations only if the waybill number hasn't been processed yet
          poidbr -= weight;
          setPoidbrut(poidbr);
          pos -= 1;
          setPosition(pos);
          
    
          // Add the waybill number to the set to mark it as processed
          processedWaybills.add(waybillNumber);
        }
      }
    }
    newdata.sort((a, b) => { // If a[0][3] and b[0][3] are the same, compare by a[0][19] and b[0][19]
      if (a[0][19] < b[0][19]) return -1;
      if (a[0][19] > b[0][19]) return 1;
      // First, compare by a[0][3] and b[0][3]
      if (a[0][3] < b[0][3]) return -1;
      if (a[0][3] > b[0][3]) return 1;
  
     
  
      // If both a[0][3] and a[0][19] are equal
      return 0;
  });
  
  
  newdata.map((row, i) => {
    if (row[0][4] == 85121000000) {
        for (let j = 0; j < newdata.length; j++) {
            if (row[0][3] == newdata[j][0][3]) {
                if (trueremaining.includes(newdata[i - 1][0][0])) {
                    if (newdata[j][0][11] > 1) {
                        newdata[j][0][11] -= 1;
                        newdata[j][0][14] -= 1;
                        break; 
                    }
                }
            }
        }
        row[0][4] = 8512100000; // This modifies the row in place
    }
    return row; // Returning the row for consistency
});

    setTotalvaluee(accumulatedTotalValue);

    let cpt = 1;
    newdata.map((data, i) => {
      const row = data[0];
      row[0] = cpt; // Update the row's first element
      cpt++; // Increment cpt
  
      if (currentSheet.length === 0) {
          currentSheet.push(header);
          currentSheet.push([
              "MASTER 1 LE 12 JUIN",
              row[0],
              3709,
              216,
              `${mawbValue} ${row[3]}`,
              ...row.slice(4) // Using spread to include the rest of the row starting from index 4
          ]);
      } else {
          currentSheet.push(["", ...row]);
      }
      
      return row; // Returning the modified row (optional for map)
  });
  
    slicedSheets.push(currentSheet);
    currentSheet = [];

    let c = 0;
    for (let i = 0; i < newdata.length; i++) {
      const row = newdata[i][0];
      c++;
      newdata[i][0][0] = c;

      const name = newdata[i][0][19];

      if (currentSheet.length === 0) {
        currentSheet.push(header);
        currentSheet.push([`sheet${sheetCount}`, 1, '', 216, (mawbValue .toString() + " " + row[3]), row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20]]);
      } else {
        let cof = 0;
        newdata.slice(i + 1).some(data => {
          if (name === data[0][19]) {
              cof++;
              return false; // Continue iterating
          }
          return true; // Exit the loop when condition is not met
      });
        if (cof > (1000 - currentSheet.length - 1) || currentSheet.length === 1001) {
          slicedSheets.push(currentSheet);
          currentSheet = [];
          c = 1;
          currentSheet.push(header);
          sheetCount += 1;
          currentSheet.push([`sheet${sheetCount}`, 1, '', 216, (mawbValue .toString() + " " + row[3]), row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20]]);
          continue;
        }
        currentSheet.push(['', ...row]);
      }
    }

    if (currentSheet.length > 0) {
      slicedSheets.push(currentSheet);
    }

    // Calculate totals for each sheet
    const sheetsWithTotals = slicedSheets.map((sheet, index) => {
      let totalPieces = 0;
      let totalValue = 0;
      let totalWeight = 0;

      // Unique waybill numbers set
      const uniqueWaybillNumbers = new Set();

      // Iterate through rows (excluding header) to calculate totals and unique waybill numbers
      sheet.slice(1).forEach(row => {
        totalPieces += Number(row[12]);
        totalValue += Number(row[10]);
        totalWeight += Number(row[14]);
        uniqueWaybillNumbers.add(row[4]); // Assuming row[4] is the waybill number in the sheet
    });
    
      totalValue = totalValue.toFixed(2);
      totalWeight = totalWeight.toFixed(2);
      
      // Add totals row at the end of the sheet
      sheet.push(["Total", "", "", "", "", "", "", "", "", "", totalValue, "", totalPieces, "", totalWeight, "", "", "", "", "", "",""]);
      
      
      const sheetName = index === 0 ? "GLOBAL" : `Sheet ${index}`;
      return {
        data: sheet,
        name: sheetName,
        totals: { pieces: totalPieces, value: totalValue, weight: totalWeight }
      };
    });

    setLoading(false);
    setSheets(sheetsWithTotals);
    
    
    slicedSheets.forEach((sheet, index) => {
      if (index === 0) {
        sheet[1][2] = pos
        console.log(pos,3333333333333);
        
        console.log(sheet[1][2]);
        
        return; // Do nothing for the first sheet
    }
      
      
    const uniqueWaybillNumbers = [...new Set(sheet.slice(1)
      .map(row => {
        const waybillValue = row[4];
        // Check if waybillValue is valid and a string, then apply the replace
        return typeof waybillValue === 'string' 
          ? waybillValue.replace(mawbValue.toString() + " ", '').trim() 
          : '';
      })
      .filter(waybillNumber => waybillNumber && waybillNumber !== "")
    )];
    

  
      // Count the number of unique waybill numbers
      const uniqueWaybillCount = uniqueWaybillNumbers.length;
        sheet[1][2] = uniqueWaybillCount;
      });
    setMissingNGP(missingNGPCodes); // Store missing NGP codes
    setSummary(true);
    setIsLoadingall(false)
    {missingNGPCodes.length > 0?setFoundngp(true):setFoundngp(false)}
    {verifier.length > 0?setFoundver(true):setFoundver(false)}
  };
};